var upsell1notification = {
        1: {
            time:"47 min. ago",
            content:'<b>Ariella Thomas </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Gagliano Castelferrato, Italy</strong> just purchased 1 Year Supply of Breathe.'
        },        
        2: {
            time:"53 min. ago",
            content:'<b>August Perkins </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Marion, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        3: {
            time:"9 min. ago",
            content:'<b>Matthew Moore </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Ponderosa Pine, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        4: {
            time:"15 min. ago",
            content:'<b>Mary Gross </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Polzeath, United Kingdom</strong> just purchased 1 Year Supply of Breathe.'
        },
        5: {
            time:"1 min. ago",
            content:'<b>Greyson Patel </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Hillerod, Denmark</strong> just purchased 1 Year Supply of Breathe.'
        },
        6: {
            time:"4 min. ago",
            content:'<b>Mateo Cruz </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Amzacea, Romania</strong> just purchased 1 Year Supply of Breathe.'
        },
        7: {
            time:"33 min. ago",
            content:'<b>Ella Miller </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Castle Bruce, Dominica</strong> just purchased 1 Year Supply of Breathe.'
        },
        8: {
            time:"1 hour ago",
            content:' <b>Avery Briggs </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Winterport, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        9: {
            time:"11 min. ago",
            content:'<b>Isabelle Ward </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Gdansk, Poland</strong> just purchased 1 Year Supply of Breathe.'
        },
        10: {
            time:"22 min. ago",
            content:'<b>Isabelle Ward </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Mehna, Germany</strong> just purchased 1 Year Supply of Breathe.'
        },
        11: {
            time:"15 min. ago",
            content:'<b>June Young </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Myrtletown, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        12: {
            time:"8 min. ago",
            content:'<b>Anthony Cook </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Union Springs, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        13: {
            time:"2 days. ago",
            content:'<b>Sage Castillo </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Agullent, Spain</strong> just purchased 1 Year Supply of Breathe.'
        },
        14: {
            time:"59 min. ago",
            content:'<b>Ximena Howard </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Caparica, Portugal</strong> just purchased 1 Year Supply of Breathe.'
        },
        15: {
            time:"25 min. ago",
            content:'<b>Maximus Wilson </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Kargow, Germany</strong> just purchased 1 Year Supply of Breathe.'
        },
        16: {
            time:"29 min. ago",
            content:'<b>Juliette Cook </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Napkor, Hungary</strong> just purchased 1 Year Supply of Breathe.'
        },
        17: {
            time:"19 min. ago",
            content:'<b>Victor James </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Farnese, Italy</strong> just purchased 1 Year Supply of Breathe.'
        },
        18: {
            time:"32 min. ago",
            content:'<b>Matteo Gutierrez </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Cristesti, Romania</strong> just purchased 1 Year Supply of Breathe.'
        },
        19: {
            time:"32 min. ago",
            content:'<b>Khloe Hale </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Bayshint, Mongolia</strong> just purchased 1 Year Supply of Breathe.'
        },
        20: {
            time:"8 min. ago",
            content:'<b>Henry Patel </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Ottobrunn. Germany</strong> just purchased 1 Year Supply of Breathe.'
        },
        21: {
            time:"56 min. ago",
            content:'<b>Brandon Norris </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Cottage Grove, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        22: {
            time:"4 min. ago",
            content:'<b>Lucy Gill </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Amzacea, Romania</strong> just purchased 1 Year Supply of Breathe.'
        },
        23: {
            time:"37 min. ago",
            content:'<b>Francisco Campbell </b> from<strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Edmonds, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        24: {
            time:"9 min. ago",
            content:'<b>Summer James </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Juzcar, Spain</strong> just purchased 1 Year Supply of Breathe.'
        },
        25: {
            time:"54 min. ago",
            content:'<b>Charlee Parson </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Andrews, United States</strong> just purchased 1 Year Supply of Breathe.'
        },
        26: {
            time:"52 min. ago",
            content:'<b>Eloise Cruz </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Tyup, Kyrgyzstan</strong> just purchased 1 Year Supply of Breathe.'
        },
        27: {
            time:"31 min. ago",
            content:' <b>Ivy Fuller </b> from <strong class="saleverify-highlight" style="color: rgb(16, 94, 251)">Benecko, Czech Republic</strong> just purchased 1 Year of Breathe.'
        }
      };

  function upsell1ShowNotification(key) {
      $('.shuffle_min').html(upsell1notification[key].time);
      $('.shuffle_content').html(upsell1notification[key].content);
      $('.shuffle_div').fadeIn();
      setTimeout(function() {
          $('.shuffle_div').fadeOut();
      }, 5000);
  }
  function upsell1DisplayNotifications() {
      var keys = Object.keys(upsell1notification);
      var index = 0;
      upsell1ShowNotification(keys[index]);
    setInterval(function() {
        index++;
        if (index >= keys.length) {
            index = 0;
        }
        upsell1ShowNotification(keys[index]);
    }, 10000);
  }

var elsHiddenList = [];
var alreadyDisplayedKey = "alreadyElsDisplayed" + SECONDS_TO_DISPLAY;
var showHiddenElements = function () {
  elsDisplayed = true;
  elsHiddenList.forEach((e) => (e.style.display = "block"));
  localStorage.setItem(alreadyDisplayedKey, true);
};

document.getElementById("showsectiononrefresh").style.display = "none";
var checkVisit = localStorage.getItem("sectionShown2");

var SECONDS_TO_DISPLAY = 325;

var startWatchVideoProgress = function () {
  console.log("Function Started");

  let isPageVisible = true;
  let isVideoVisible = true;
  let isVideoPlayed = false;
  let currentInstance = null; // Initialize currentInstance to null
  let hasTabSwitched = false;

  document.addEventListener("visibilitychange", function () {
    isPageVisible = !document.hidden;
    console.log(
      "Page visibility changed. Page is now " +
        (isPageVisible ? "visible" : "hidden")
    );

    // Check visibility on page change
    checkVisibility();
  });

  const smartPlayerContainer = document.querySelector("#smartplayer");

  smartplayer.instances.forEach(function (instance) {
    let isPlaying = false;
    let isFirstClick = true;

    instance.on("play", () => {

      if (smartplayer.instances[0].smartAutoPlay) return;

      window.scrollTo({
        top: 0,
        behavior: "instant",
      });
      
      console.log("Video is playing");

      // Check if the play event is user-initiated
      if (!isVideoPlayed && isPageVisible && !hasTabSwitched) {
        isVideoPlayed = true;
        console.log("First click on the video");
        // Add your logic for the first click on the video here
      }

      isPlaying = true; // Set the flag when the video starts playing
      currentInstance = instance; // Update the current instance
      checkVisibility();
    });

    instance.on("pause", () => {
      console.log("Video is paused");
      // Your existing code...
      isPlaying = false; // Reset the flag when the video is paused
      // checkVisibility(); // Check visibility when video is paused
      minimizeVideo();
    });

    instance.on("timeupdate", () => {
      // Your existing code...
      checkVisibility(); // Check visibility on time update
      if (
        instance.analytics.player.options.id == "66ace1b1b8e8e6000b826b59" // Desktop video ID
      ) {
        SECONDS_TO_DISPLAY = 325;
      } else if (
        instance.analytics.player.options.id == "66ace377b92b0d000b333acc" // Mobile video ID
      ) {
        SECONDS_TO_DISPLAY = 325;
      }

      if (
        !instance.video.paused &&
        instance.video.currentTime >= SECONDS_TO_DISPLAY
      ) {
        if (checkVisit == null) {
          checkVisit = true;
          console.log("Show Contents");
          localStorage.setItem("sectionShown2", true);
          contentsDisplayed = true;
          checkVisit = localStorage.getItem("sectionShown2");
          document.getElementById("showsectiononrefresh").style.display =
            "block";
          document.getElementById("shuffle").style.display = "block";
          setTimeout(function () {
            console.log("Watched Video");
            upsell1DisplayNotifications();
 
          }, 1000);
        }
      }
    });

    // Scroll event listener to check if the video is in view
    window.addEventListener("scroll", function () {
      const videoRect = smartPlayerContainer.getBoundingClientRect();
      isVideoVisible =
        videoRect.top >= 0 &&
        videoRect.bottom <= window.innerHeight &&
        videoRect.left >= 0 &&
        videoRect.right <= window.innerWidth;

      // Check visibility on scroll
      checkVisibility();
    });

    // Detect tab switches
    window.addEventListener("blur", function () {
      hasTabSwitched = true;
      console.log("Tab switched True");
    });

    window.addEventListener("focus", function () {
      hasTabSwitched = false;
      console.log("Tab switched False");
    });
  });

  function checkVisibility() {
    const videoElement = smartPlayerContainer
      ? smartPlayerContainer.querySelector("video")
      : null;

      if (isVideoPlayed && !videoElement.paused) {
        maximizeVideo();
      } 
  }

  function maximizeVideo() {
    // Your code to maximize the video

    console.log("Maximize Video");
    // Start Maximize Video
    let videosection = document.querySelector("#video");
    let bodyselector = document.querySelector("body");
    let videocontainer = document.querySelector("#video > div");
    let videotop = document.querySelector("#video > div > div");
    let videoh3 = document.querySelector(".top-1");
    let videoh1 = document.querySelector(".top-2");
    let video = document.querySelector("#smartplayer");
    let smartvideowrap = document.querySelector(
      "#smartplayer > div > div.smartplayer-video-wrap"
    );
    let MainVidWrapper = document.querySelector("#vid-wrapper");
    let vidwrapper = document.querySelector("#smartplayer > div");
    let vidwrappervid = document.querySelector(
      "#smartplayer > div > div.smartplayer-video-wrap > video"
    );
    vidwrappervid.style.objectFit = "contain";
    video.style.display = "contents";

    // bodyselector.style.overflow = "hidden";
    


    if (window.innerWidth < 700) {
      videosection.style.height = "96vh";
      videosection.style.height = "96dvh";
      vidwrapper.style.height = "100vh";
      vidwrapper.style.height = "100dvh";
      video.style.position = "static";
      vidwrappervid.style.objectFit = "fill";
      vidwrappervid.style.background = "#000";
    } else {
      videocontainer.style.maxWidth = "100%";
      MainVidWrapper.style.width = "100%";
      MainVidWrapper.style.maxWidth = "100%";
      MainVidWrapper.style.position = "relative";
      MainVidWrapper.style.height = "100vh";
      videocontainer.style.padding = "0px";
      smartvideowrap.style.height = "100vh";
      vidwrapper.style.height = "100vh";
      vidwrappervid.style.background = "#000";
      videotop.style.marginTop = "0px !important";
      videoh3.style.display = "none";
      videoh1.style.display = "none";
      videosection.style.paddingTop = "0px";
    }
    // End Maximize Video
  }

  function minimizeVideo() {
    // Your code to minimize the video
    console.log("Minimize Video");
    // Start Minimize Video
    let bodyselector = document.querySelector("body");
    let videosection = document.querySelector("#video");
    let videocontainer = document.querySelector("#video > div");
    let MainVidWrapper = document.querySelector("#vid-wrapper");
    let videotop = document.querySelector("#video > div > div");
    let videoh3 = document.querySelector(".top-1");
    let videoh1 = document.querySelector(".top-2");
    let video = document.querySelector("#smartplayer");
    let vidwrapper = document.querySelector("#smartplayer > div");
    let vidwrappervid = document.querySelector(
      "#smartplayer > div > div.smartplayer-video-wrap > video"
    );
    let smartvideowrap = document.querySelector(
      "#smartplayer > div > div.smartplayer-video-wrap"
    );
    video.style.position = "relative";
    video.style.display = "block";

    bodyselector.style.overflow = "auto";

    if (window.innerWidth < 700) {
      videosection.style.height = "auto";
      vidwrapper.style.height = "auto";
      vidwrappervid.style.objectFit = "cover";
      video.style.background = "transparent";
      vidwrappervid.style.background = "transparent";
    } else {
      videocontainer.style.maxWidth = "initial";
      videocontainer.style.height = "auto";
      MainVidWrapper.style.height = "auto";
      MainVidWrapper.style.width = "100%";
      MainVidWrapper.style.maxWidth = "900px";
      MainVidWrapper.style.maxHeight = "none";
      MainVidWrapper.style.margin = "auto";
      MainVidWrapper.style.position = "relative";
      MainVidWrapper.style.top = "0px";
      MainVidWrapper.style.left = "0px";
      video.style.height = "auto";
      smartvideowrap.style.height = "auto";
      vidwrapper.style.height = "auto";
      vidwrappervid.style.objectFit = "cover";
      videotop.style.marginTop = "1rem !important";
      videoh3.style.display = "block";
      videoh1.style.display = "flex";
    }
    // End Minimize Video
  }
};

 function checkSmartPlayer() {
   if (typeof smartplayer !== 'undefined') {
       startWatchVideoProgress();
       console.log('smartPlayer object found:', smartplayer);
   } else {
       console.log('smartPlayer object not found. Checking again in 1 second...');
       setTimeout(checkSmartPlayer, 1000);
   }
 }

 checkSmartPlayer();

if (checkVisit == "false") {
  document.getElementById("showsectiononrefresh").style.display = "none";
  document.getElementById("shuffle").style.display = "none";
  console.log("Have Not Watched the Video");
}
if (checkVisit == null) {
  document.getElementById("showsectiononrefresh").style.display = "none";
  document.getElementById("shuffle").style.display = "none";
  console.log("Initial Visit");
}
if (checkVisit === "true") {
  document.getElementById("showsectiononrefresh").style.display = "block";
  document.getElementById("shuffle").style.display = "block";
  setTimeout(function () {
    console.log("Watched Video");
    upsell1DisplayNotifications();
  }, 1000);
}